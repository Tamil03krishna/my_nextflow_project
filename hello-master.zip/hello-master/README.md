Hello world script
====================

A simple script showing the basic Hello World! example for the Nextflow framework. 
